/*
 */
package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Conectar {
    
    private static Connection conn;
    private static final String driver="org.gjt.mm.mysql.Driver";
    private static final String user="root";
    private static final String password="";
   // private static final String url="jdbc:mysql://localhost:3306/mitiendita";
    private static final String url="jdbc:mysql://localhost:33065/cursosnestor?characterEncoding=latin1";
    
    public Conectar(){
        conn=null;
        try {
            Class.forName(driver);
            conn = (Connection) DriverManager.getConnection(url, user, password);
            if(conn!=null){
                System.out.println("Conexión establecida...");
            }
        } catch (Exception e) {
                System.out.println("Error al conectar..." + e);
        }
    }
    
    //este metodo nos retorna la conexion
    public Connection getConnection(){
        return conn;
    }
    
    public void desconectar(){
        conn=null;
        if(conn==null){
            System.out.println("Conexión terminada");
        }
    }
    
}

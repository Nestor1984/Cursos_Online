/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

public class vModulo { //Esta es la super clase
    
    private int iddelmodulo;
    private String nombredelmodulo;
    private String descripcion;

    //Constructor por defecto
    public vModulo() {
    }
    
    //Constructor con parametros
    public vModulo(int iddelmodulo, String nombredelmodulo, String descripcion) {
        this.iddelmodulo = iddelmodulo;
        this.nombredelmodulo = nombredelmodulo;
        this.descripcion = descripcion;
    }
    
    //Metodos getter and setters

    public int getIddelmodulo() {
        return iddelmodulo;
    }

    public void setIddelmodulo(int iddelmodulo) {
        this.iddelmodulo = iddelmodulo;
    }

    public String getNombredelmodulo() {
        return nombredelmodulo;
    }

    public void setNombredelmodulo(String nombredelmodulo) {
        this.nombredelmodulo = nombredelmodulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

/**
 *
 * @author Usuario
 */
public class vDocentes {
    
    //Definimos los atributos de la clase
    //Para manejar campos de tabla docente (mysql)
    private int iddocente;
    private String nombredocente;

    //Constructor por defecto
    public vDocentes() {
    }
    
    //Constructor para inicializar los atributos
    public vDocentes(int iddocente, String nombredocente) {
        this.iddocente = iddocente;
        this.nombredocente = nombredocente;
    }
    
    //Metodos getters y setters para los dos atributos

    public int getIddocente() {
        return iddocente;
    }

    public void setIddocente(int iddocente) {
        this.iddocente = iddocente;
    }

    public String getNombredocente() {
        return nombredocente;
    }

    public void setNombredocente(String nombredocente) {
        this.nombredocente = nombredocente;
    }
    
}

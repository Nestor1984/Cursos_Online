/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

/**
 *
 * @author Usuario
 */
public class vDepartamento {
    
    private int iddeldepartamento;
    private String nombredeldepartamento;
    private String pais;

    public vDepartamento() {
    }

    public int getIddeldepartamento() {
        return iddeldepartamento;
    }

    public void setIddeldepartamento(int iddeldepartamento) {
        this.iddeldepartamento = iddeldepartamento;
    }

    public String getNombredeldepartamento() {
        return nombredeldepartamento;
    }

    public void setNombredeldepartamento(String nombredeldepartamento) {
        this.nombredeldepartamento = nombredeldepartamento;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }
    
    
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

public class vLeccion extends vModulo{ //Esta subclase hereda todos los atributos y metodos de la super clase vLeccion
    
    //Atributos propios de la clase vLeccion
    //Como medida de seguridad encapsulamos los atributos
    private int iddelaleccion;
    private String titulodelaleccion;
    private String contenidodelaleccion;
    
    //Aqui aplicamos la sobrecarga de constructores
    //Constructor por defecto
    public vLeccion(){
    }
    
    //Constructor con parametros
    public vLeccion(int iddelaleccion, String titulodelaleccion, String contenidodelaleccion){
        this.iddelaleccion = iddelaleccion;
        this.titulodelaleccion = titulodelaleccion;
        this.contenidodelaleccion = contenidodelaleccion;
    }

    public int getIddelaleccion() {
        return iddelaleccion;
    }

    public void setIddelaleccion(int iddelaleccion) {
        this.iddelaleccion = iddelaleccion;
    }
    
    public String getTitulodelaleccion() {
        return titulodelaleccion;
    }

    public void setTitulodelaleccion(String titulodelaleccion) {
        this.titulodelaleccion = titulodelaleccion;
    }

    public String getContenidodelaleccion() {
        return contenidodelaleccion;
    }

    public void setContenidodelaleccion(String contenidodelaleccion) {
        this.contenidodelaleccion = contenidodelaleccion;
    }
    
    
    
}


package Datos;

public class vEstudiantes {
    
    //Encapsulamos los atributos de la clase
    private int idestudiante;
    private String nombre;
    private String apellido;
    private int edad;
    
    //Constructor por defecto
    public vEstudiantes() {
    }
    
    //Constructor con parametros

    public vEstudiantes(int idestudiante, String nombre, String apellido, int edad) {
        this.idestudiante = idestudiante;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
    }
    
    
    //Metodos setters y getters
    public int getIdestudiante() {
        return idestudiante;
    }

    public void setIdestudiante(int idestudiante) {
        this.idestudiante = idestudiante;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    
}

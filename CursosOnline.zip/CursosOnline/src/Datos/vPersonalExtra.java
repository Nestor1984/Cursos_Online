/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

/**
 *
 * @author Usuario
 */
public class vPersonalExtra extends vDepartamento{
    
    private int idpersonal;
    private String nombrepersonal;
    private String apellidopersonal;

    public vPersonalExtra() {
    }

    public vPersonalExtra(int idpersonal, String nombrepersonal, String apellidopersonal) {
        this.idpersonal = idpersonal;
        this.nombrepersonal = nombrepersonal;
        this.apellidopersonal = apellidopersonal;
    }

    public int getIdpersonal() {
        return idpersonal;
    }

    public void setIdpersonal(int idpersonal) {
        this.idpersonal = idpersonal;
    }

    public String getNombrepersonal() {
        return nombrepersonal;
    }

    public void setNombrepersonal(String nombrepersonal) {
        this.nombrepersonal = nombrepersonal;
    }

    public String getApellidopersonal() {
        return apellidopersonal;
    }

    public void setApellidopersonal(String apellidopersonal) {
        this.apellidopersonal = apellidopersonal;
    }
    
    
    
    
}

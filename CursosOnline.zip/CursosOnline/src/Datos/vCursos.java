/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;
/**
 *
 * @author Usuario
 */
public class vCursos {
    
    //Encapsulamos los atributos
    private int idcurso;
    private String descripcion;
    private String nombredelcurso;
    private String nivel;
    private float precio_curso;
    private int nrodesemanas;
    
    //Constructor por defecto
    public vCursos() {
    }
    
    //Costructor con parametros

    public vCursos(int idcurso, String descripcion, String nombredelcurso, String nivel, float precio_curso, int nrodesemanas) {
        this.idcurso = idcurso;
        this.descripcion = descripcion;
        this.nombredelcurso = nombredelcurso;
        this.nivel = nivel;
        this.precio_curso = precio_curso;
        this.nrodesemanas = nrodesemanas;
    }
    
    //Setters y getters para todos los atributos

    public int getIdcurso() {
        return idcurso;
    }

    public void setIdcurso(int idcurso) {
        this.idcurso = idcurso;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getNombredelcurso() {
        return nombredelcurso;
    }

    public void setNombredelcurso(String nombredelcurso) {
        this.nombredelcurso = nombredelcurso;
    }

    public String getNivel() {
        return nivel;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }

    public float getPrecio_curso() {
        return precio_curso;
    }

    public void setPrecio_curso(float precio_curso) {
        this.precio_curso = precio_curso;
    }

    public int getNrodesemanas() {
        return nrodesemanas;
    }

    public void setNrodesemanas(int nrodesemanas) {
        this.nrodesemanas = nrodesemanas;
    }

    
    
    
}

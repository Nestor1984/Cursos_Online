/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

import Datos.vCursos;
import conexion.Conectar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class fCursos {
    
    //PROGRAMACION DEL CRUD
    private Conectar mysql = new Conectar();//conexion bd
    private Connection cn = mysql.getConnection(); //conexion bd
    private String sSQL = ""; //Para escribir instruccion sql
    public Integer totalregistros;//Para contar registros
    //Para la tabla
    public DefaultTableModel mostrar(String buscar) {
        DefaultTableModel modelo;

        String[] titulos = {"Id_Curso", "Descripcion", "Nombre_Curso", "Nivel", "Precio_Curso", "Nro_De_Semanas"}; //LOS NOMBRES DE MIS CAMPOS (2 EN ESTE CASO)
        String[] registro = new String[6];
        totalregistros = 0; //Iniciamos la variable global en cero
        modelo = new DefaultTableModel(null, titulos); //Mostramos el modelo, en la parte del titulo, tabla

        sSQL = "select * from curso where nombredelcurso like '%" + buscar + "%' order by idcurso";

        try {
            Statement st = cn.createStatement(); //
            ResultSet rs = st.executeQuery(sSQL); //Vamos a arrogar todo lo q se ejecute en el sql
            while (rs.next()) { //mientras rs.next sea true repite esto
                registro[0] = rs.getString("idcurso"); //Llenamos nuestro vector de registros
                registro[1] = rs.getString("descripcion"); //Llenamos nuestro vector de registros
                registro[2] = rs.getString("nombredelcurso"); //Llenamos nuestro vector de registros
                registro[3] = rs.getString("nivel"); //Llenamos nuestro vector de registros
                registro[4] = rs.getString("precio_curso"); //Llenamos nuestro vector de registros
                registro[5] = rs.getString("nrodesemanas"); //Llenamos nuestro vector de registros
                
                totalregistros = totalregistros + 1; //Contamos los registros
                modelo.addRow(registro); //Vamos a adicionar en nuestra tabla cada registro
            }
            return modelo; //vamos a mostrar los registros en la tabla, retornamos modelo
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return null;
        }
    }

    public boolean insertar(vCursos dts) { 
        sSQL = "insert into curso (descripcion, nombredelcurso, nivel, precio_curso, nrodesemanas) values(?, ?, ?, ?, ?)"; //Vamos a insertar en el campo nombre, id se va autoincrementar
        try {
            PreparedStatement pst = cn.prepareStatement(sSQL);
            pst.setString(1, dts.getDescripcion());
            pst.setString(2, dts.getNombredelcurso());
            pst.setString(3, dts.getNivel());
            pst.setFloat(4, dts.getPrecio_curso());
            pst.setInt(5, dts.getNrodesemanas());

            int n = pst.executeUpdate(); 
            if (n != 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
    }

    public boolean editar(vCursos dts) {
        sSQL = "update curso set descripcion=?, nombredelcurso=?, nivel=?, precio_curso=?, nrodesemanas=? where idcurso=?";

        try {
            PreparedStatement pst = cn.prepareStatement(sSQL);
            pst.setString(1, dts.getDescripcion()); //Para actualizar descripcion curso
            pst.setString(2, dts.getNombredelcurso()); //Para actualizar nombre curso
            pst.setString(3, dts.getNivel());
            pst.setFloat(4, dts.getPrecio_curso());
            pst.setInt(5, dts.getNrodesemanas());
            
            int n = pst.executeUpdate();
            if (n != 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }

    }

    public boolean eliminar(vCursos dts) {
        sSQL = "delete from curso where idcurso=?";
        try {
            PreparedStatement pst = cn.prepareStatement(sSQL);
            pst.setInt(1, dts.getIdcurso());//k
            int n = pst.executeUpdate();              
            if (n != 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }

    }
    
}

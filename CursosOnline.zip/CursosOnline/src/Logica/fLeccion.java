/*
 */
package Logica;
//import Datos.vCliente;
import Datos.vLeccion;
import conexion.Conectar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class fLeccion {
    
    private Conectar mysql = new Conectar();
    private Connection cn = mysql.getConnection();
    private String sSQL = "";
    private String sSQL2 = "";
    public Integer totalregistros;
    
     public DefaultTableModel mostrar(String buscar) {
        DefaultTableModel modelo;

        String[] titulos = {"ID_Del_Modulo", "Nombre_Del_Modulo", "Descripcion", "ID_Leccion", "Titulo_Leccion", "Contenido_De_La_Leccion"};

        String[] registro = new String[6];
        totalregistros = 0;
        modelo = new DefaultTableModel(null, titulos);

        sSQL = "select m.iddelmodulo,m.nombredelmodulo,m.descripciondelmodulo,l.iddelaleccion,"
                + "l.titulodelaleccion,l.contenidodelaleccion from modulo m inner join leccion l "
                + "on m.iddelmodulo=l.iddelmodulo where nombredelmodulo like '%"
                + buscar + "%' order by iddelmodulo desc";

        try {
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sSQL);
            while (rs.next()) {
                registro[0] = rs.getString("iddelmodulo");
                registro[1] = rs.getString("nombredelmodulo");
                registro[2] = rs.getString("descripciondelmodulo");
                registro[3] = rs.getString("iddelaleccion");
                registro[4] = rs.getString("titulodelaleccion");
                registro[5] = rs.getString("contenidodelaleccion");

                totalregistros = totalregistros + 1;
                modelo.addRow(registro);
            }
            return modelo;
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return null;
        }
    }
    
   
        public boolean insertar(vLeccion dts) {
        sSQL = "insert into modulo (nombredelmodulo,descripciondelmodulo)" //Clase padre
                + "values(?,?)";
        sSQL2 = "insert into leccion (iddelaleccion, iddelmodulo,titulodelaleccion,contenidodelaleccion)" //Clase hija
                + "values ((select iddelmodulo from modulo order by iddelmodulo desc limit 1),?,?,?)";
        try {
            PreparedStatement pst = cn.prepareStatement(sSQL);
            PreparedStatement pst2 = cn.prepareStatement(sSQL2);
            pst.setString(1, dts.getNombredelmodulo());
            pst.setString(2, dts.getDescripcion());

           /* pst2.setString(1, dts.getTitulodelaleccion());
            pst2.setString(2, dts.getContenidodelaleccion());*/
           
            pst2.setInt(1, dts.getIddelaleccion());
            pst2.setString(2, dts.getTitulodelaleccion());
            pst2.setString(3, dts.getContenidodelaleccion());
  
            int n = pst.executeUpdate();
            if (n != 0) {
                int n2 = pst2.executeUpdate();

                if (n2 != 0) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
    }
        
        public boolean editar(vLeccion dts) {
        sSQL = "update modulo set nombredelmodulo=?,descripciondelmodulo=?";
        sSQL2 = "update leccion set iddelmodulo=?,titulodelaleccion=?,contenidodelaleccion=?"
                + " where iddelmodulo=?";
        try {
            PreparedStatement pst = cn.prepareStatement(sSQL);
            PreparedStatement pst2 = cn.prepareStatement(sSQL2);
            pst.setString(1, dts.getNombredelmodulo());
            pst.setString(2, dts.getDescripcion());

            pst2.setInt(1, dts.getIddelmodulo());
            pst2.setString(2, dts.getTitulodelaleccion());
            pst2.setString(3, dts.getContenidodelaleccion());
           
            int n = pst.executeUpdate();
            if (n != 0) {
                int n2 = pst2.executeUpdate();

                if (n2 != 0) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
    }    
     
    public boolean eliminar(vLeccion dts) {
        sSQL = "delete from leccion where iddelmodulo=?";
        sSQL2 = "delete from modulo where iddelmodulo=?";
        try {
            PreparedStatement pst = cn.prepareStatement(sSQL);
            PreparedStatement pst2 = cn.prepareStatement(sSQL2);

            pst.setInt(1, dts.getIddelmodulo());
            pst2.setInt(1, dts.getIddelmodulo());
            int n = pst.executeUpdate();
            if (n != 0) {
                int n2 = pst2.executeUpdate();

                if (n2 != 0) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
    }
        
     public DefaultTableModel login(String login, String password) {
        DefaultTableModel modelo;

        String[] titulos = {"ID", "Nombre", "Apaterno", "Amaterno", "Acceso", "Login", "Clave", "Estado"};

        String[] registro = new String[8];
        totalregistros = 0;
        modelo = new DefaultTableModel(null, titulos);

        sSQL = "select p.idpersona,p.nombre,p.apaterno,p.amaterno,"
                + "t.acceso,t.login,t.password,t.estado from persona p inner join trabajador t "
                + "on p.idpersona=t.idpersona where t.login='"
                + login + "' and t.password='" + password + "' and t.estado='A'";

        try {
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sSQL);
            while (rs.next()) {
                registro[0] = rs.getString("idpersona");
                registro[1] = rs.getString("nombre");
                registro[2] = rs.getString("apaterno");
                registro[3] = rs.getString("amaterno");
                registro[4] = rs.getString("acceso");
                registro[5] = rs.getString("login");
                registro[6] = rs.getString("password");
                registro[7] = rs.getString("estado");

                totalregistros = totalregistros + 1;
                modelo.addRow(registro);
            }
            return modelo;
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return null;
        }
    }    
        
}

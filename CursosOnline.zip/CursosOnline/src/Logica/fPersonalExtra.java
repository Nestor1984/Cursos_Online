/*
 */
package Logica;
//import Datos.vCliente;
import Datos.vPersonalExtra;
import conexion.Conectar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class fPersonalExtra {
    
    private Conectar mysql = new Conectar();
    private Connection cn = mysql.getConnection();
    private String sSQL = "";
    private String sSQL2 = "";
    public Integer totalregistros;
    
     public DefaultTableModel mostrar(String buscar) {
        DefaultTableModel modelo;

        String[] titulos = {"ID_Departamento", "Nombre_Departamento", "Pais", "ID_Personal", "Nombre_Personal", "Apellido_Personal"};

        String[] registro = new String[6];
        totalregistros = 0;
        modelo = new DefaultTableModel(null, titulos);

        sSQL = "select d.iddeldepartamento,d.nombredeldepartamento,d.pais,p.idpersonal,"
                + "p.nombrepersonal,p.apellidopersonal from departamento d inner join personalextra p "
                + "on d.iddeldepartamento=p.iddeldepartamento where nombredeldepartamento like '%"
                + buscar + "%' order by iddeldepartamento desc";

        try {
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sSQL);
            while (rs.next()) {
                registro[0] = rs.getString("iddeldepartamento");
                registro[1] = rs.getString("nombredeldepartamento");
                registro[2] = rs.getString("pais");
                registro[3] = rs.getString("idpersonal");
                registro[4] = rs.getString("nombrepersonal");
                registro[5] = rs.getString("apellidopersonal");

                totalregistros = totalregistros + 1;
                modelo.addRow(registro);
            }
            return modelo;
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return null;
        }
    }
     
    public boolean insertar(vPersonalExtra dts) {
        sSQL = "insert into departamento (nombredeldepartamento,pais)" //Clase padre
                + "values(?,?)";
        sSQL2 = "insert into personalextra (idpersonal, iddeldepartamento, nombrepersonal, apellidopersonal)" //Clase hija
                + "values ((select iddeldepartamento from departamento order by iddeldepartamento desc limit 1),?,?,?)";
        try {
            PreparedStatement pst = cn.prepareStatement(sSQL);
            PreparedStatement pst2 = cn.prepareStatement(sSQL2);
            pst.setString(1, dts.getNombredeldepartamento());
            pst.setString(2, dts.getPais());

           /* pst2.setString(1, dts.getTitulodelaleccion());
            pst2.setString(2, dts.getContenidodelaleccion());*/
           
            pst2.setInt(1, dts.getIdpersonal());
            pst2.setString(2, dts.getNombrepersonal());
            pst2.setString(3, dts.getApellidopersonal());
  
            int n = pst.executeUpdate();
            if (n != 0) {
                int n2 = pst2.executeUpdate();

                if (n2 != 0) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
    }
    
    public boolean editar(vPersonalExtra dts) {
        sSQL = "update departamento set nombredeldepartamento=?,pais=?";
        sSQL2 = "update leccion set iddeldepartamento=?,nombrepersonal=?,apellidopersonal=?"
                + " where iddeldepartamento=?";
        try {
            PreparedStatement pst = cn.prepareStatement(sSQL);
            PreparedStatement pst2 = cn.prepareStatement(sSQL2);
            pst.setString(1, dts.getNombredeldepartamento());
            pst.setString(2, dts.getPais());

            pst2.setInt(1, dts.getIddeldepartamento());
            pst2.setString(2, dts.getNombrepersonal());
            pst2.setString(3, dts.getApellidopersonal());
           
            int n = pst.executeUpdate();
            if (n != 0) {
                int n2 = pst2.executeUpdate();

                if (n2 != 0) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
    }    
    
    public boolean eliminar(vPersonalExtra dts) {
        sSQL = "delete from personalextra where iddeldepartamento=?";
        sSQL2 = "delete from departamento where iddeldepartamento=?";
        try {
            PreparedStatement pst = cn.prepareStatement(sSQL);
            PreparedStatement pst2 = cn.prepareStatement(sSQL2);

            pst.setInt(1, dts.getIddeldepartamento());
            pst2.setInt(1, dts.getIddeldepartamento());
            int n = pst.executeUpdate();
            if (n != 0) {
                int n2 = pst2.executeUpdate();

                if (n2 != 0) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
    }
    
    
    
}

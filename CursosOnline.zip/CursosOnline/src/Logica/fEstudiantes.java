/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;
import Datos.vEstudiantes;
import conexion.Conectar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class fEstudiantes {
    
    //PROGRAMACION DEL CRUD
    private Conectar mysql = new Conectar();//conexion bd
    private Connection cn = mysql.getConnection(); //conexion bd
    private String sSQL = ""; //Para escribir instruccion sql
    public Integer totalregistros;//Para contar registros
    //Para la tabla
    public DefaultTableModel mostrar(String buscar) {
        DefaultTableModel modelo;

        String[] titulos = {"Id_Estudiante", "Nombre_Estudiante", "Apellido_Estudiante", "edad"}; //LOS NOMBRES DE MIS CAMPOS (2 EN ESTE CASO)
        String[] registro = new String[4];
        totalregistros = 0; //Iniciamos la variable global en cero
        modelo = new DefaultTableModel(null, titulos); //Mostramos el modelo, en la parte del titulo, tabla

        sSQL = "select * from estudiante where nombre like '%" + buscar + "%' order by idestudiante";

        try {
            Statement st = cn.createStatement(); //
            ResultSet rs = st.executeQuery(sSQL); //Vamos a arrogar todo lo q se ejecute en el sql
            while (rs.next()) { //mientras rs.next sea true repite esto
                registro[0] = rs.getString("idestudiante"); //Llenamos nuestro vector de registros
                registro[1] = rs.getString("nombre"); //Llenamos nuestro vector de registros
                registro[2] = rs.getString("apellido"); //Llenamos nuestro vector de registros
                registro[3] = rs.getString("edad"); //Llenamos nuestro vector de registros
                
                totalregistros = totalregistros + 1; //Contamos los registros
                modelo.addRow(registro); //Vamos a adicionar en nuestra tabla cada registro
            }
            return modelo; //vamos a mostrar los registros en la tabla, retornamos modelo
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return null;
        }
    }

    public boolean insertar(vEstudiantes dts) { 
        sSQL = "insert into estudiante (nombre, apellido, edad) values(?, ?, ?)"; //Vamos a insertar en el campo nombre, id se va autoincrementar
        try {
            PreparedStatement pst = cn.prepareStatement(sSQL);
            pst.setString(1, dts.getNombre());
            pst.setString(2, dts.getApellido());
            pst.setInt(3, dts.getEdad());

            int n = pst.executeUpdate(); 
            if (n != 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
    }

    public boolean editar(vEstudiantes dts) {
        sSQL = "update estudiante set nombre=?, apellido=?, edad=? where idestudiante=?";

        try {
            PreparedStatement pst = cn.prepareStatement(sSQL);
            pst.setString(1, dts.getNombre()); //Para actualizar nombre estudiante
            pst.setString(2, dts.getApellido());
            pst.setInt(3, dts.getEdad());
           
            int n = pst.executeUpdate();
            if (n != 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }

    }

    public boolean eliminar(vEstudiantes dts) {
        sSQL = "delete from estudiante where idestudiante=?";
        try {
            PreparedStatement pst = cn.prepareStatement(sSQL);
            pst.setInt(1, dts.getIdestudiante());//k
            int n = pst.executeUpdate();              
            if (n != 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }

    }
    
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

import Datos.vDocentes;
import conexion.Conectar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class fDocentes {
    
    //PROGRAMACION DEL CRUD
    private Conectar mysql = new Conectar();//conexion bd
    private Connection cn = mysql.getConnection(); //conexion bd
    private String sSQL = ""; //Para escribir instruccion sql
    public Integer totalregistros;//Para contar registros
    //Para la tabla
    public DefaultTableModel mostrar(String buscar) {
        DefaultTableModel modelo;

        String[] titulos = {"Id_Docente", "Nombre_Docente"}; //LOS NOMBRES DE MIS CAMPOS (2 EN ESTE CASO)
        String[] registro = new String[2];
        totalregistros = 0; //Iniciamos la variable global en cero
        modelo = new DefaultTableModel(null, titulos); //Mostramos el modelo, en la parte del titulo, tabla

        sSQL = "select * from docente where nombredocente like '%" + buscar + "%' order by iddocente";

        try {
            Statement st = cn.createStatement(); //
            ResultSet rs = st.executeQuery(sSQL); //Vamos a arrogar todo lo q se ejecute en el sql
            while (rs.next()) { //mientras rs.next sea true repite esto
                registro[0] = rs.getString("iddocente"); //Llenamos nuestro vector de registros
                registro[1] = rs.getString("nombredocente"); //Llenamos nuestro vector de registros

                totalregistros = totalregistros + 1; //Contamos los registros
                modelo.addRow(registro); //Vamos a adicionar en nuestra tabla cada registro
            }
            return modelo; //vamos a mostrar los registros en la tabla, retornamos modelo
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return null;
        }
    }

    public boolean insertar(vDocentes dts) { 
        sSQL = "insert into docente (nombredocente) values(?)"; //Vamos a insertar en el campo nombre, id se va autoincrementar
        try {
            PreparedStatement pst = cn.prepareStatement(sSQL);
            pst.setString(1, dts.getNombredocente());

            int n = pst.executeUpdate(); 
            if (n != 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
    }

    public boolean editar(vDocentes dts) {
        sSQL = "update docente set nombredocente=? where iddocente=?";

        try {
            PreparedStatement pst = cn.prepareStatement(sSQL);
            pst.setString(1, dts.getNombredocente()); //Para actualizar nombre docente
            
            pst.setInt(2,dts.getIddocente());
            int n = pst.executeUpdate();
            if (n != 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
    }

    public boolean eliminar(vDocentes dts) {
        sSQL = "delete from docente where iddocente=?";
        try {
            PreparedStatement pst = cn.prepareStatement(sSQL);
            pst.setInt(1, dts.getIddocente());//k
            int n = pst.executeUpdate();              
            if (n != 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
    }
}

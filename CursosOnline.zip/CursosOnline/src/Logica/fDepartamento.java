/*
 */
package Logica;

import Datos.vDepartamento;
import conexion.Conectar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class fDepartamento {
    
    //PROGRAMACION DEL CRUD
    private Conectar mysql = new Conectar();//conexion bd
    private Connection cn = mysql.getConnection(); //conexion bd
    private String sSQL = ""; //Para escribir instruccion sql
    public Integer totalregistros;//Para contar registros
    
          //Para la tabla
    public DefaultTableModel mostrar(String buscar) {
        DefaultTableModel modelo;

        String[] titulos = {"Id_Del_Departamente", "Nombre_del_Departamento", "Pais"}; //LOS NOMBRES DE MIS CAMPOS (3 EN ESTE CASO)
        String[] registro = new String[3];
        totalregistros = 0; //Iniciamos la variable global en cero
        modelo = new DefaultTableModel(null, titulos); //Mostramos el modelo, en la parte del titulo, tabla

        sSQL = "select * from departamento where nombredeldepartamento like '%" + buscar + "%' order by iddeldepartamento";

        try {
            Statement st = cn.createStatement(); //
            ResultSet rs = st.executeQuery(sSQL); //Vamos a arrogar todo lo q se ejecute en el sql
            while (rs.next()) { //mientras rs.next sea true repite esto
                registro[0] = rs.getString("iddeldepartamento"); //Llenamos nuestro vector de registros
                registro[1] = rs.getString("nombredeldepartamento"); //Llenamos nuestro vector de registros
                registro[2] = rs.getString("pais"); //Llenamos nuestro vector de registros
                
                totalregistros = totalregistros + 1; //Contamos los registros
                modelo.addRow(registro); //Vamos a adicionar en nuestra tabla cada registro
            }
            return modelo; //vamos a mostrar los registros en la tabla, retornamos modelo
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return null;
        }
    }
    
    public boolean insertar(vDepartamento dts) { 
        sSQL = "insert into  departamento(nombredeldepartamento, pais) values(?, ?)"; //Vamos a insertar en el campo nombre, iddelmodulo se va autoincrementar
        try {
            PreparedStatement pst = cn.prepareStatement(sSQL);
            pst.setString(1, dts.getNombredeldepartamento());
            pst.setString(2, dts.getPais());

            int n = pst.executeUpdate(); 
            if (n != 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }
    }
    
    public boolean editar(vDepartamento dts) {
        sSQL = "update departamento set nombredeldepartamento=?, pais=? where iddeldepartamento=?";

        try {
            PreparedStatement pst = cn.prepareStatement(sSQL);
            pst.setString(1, dts.getNombredeldepartamento()); //Para actualizar nombre del departamento
            pst.setString(2, dts.getPais()); //Para actualizar descripcion del departamento
            int n = pst.executeUpdate();
            if (n != 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }

    }
    
    public boolean eliminar(vDepartamento dts) {
        sSQL = "delete departamento from  where iddeldepartamento=?";
        try {
            PreparedStatement pst = cn.prepareStatement(sSQL);
            pst.setInt(1, dts.getIddeldepartamento());//k
            int n = pst.executeUpdate();              
            if (n != 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        }

    }
    
}
